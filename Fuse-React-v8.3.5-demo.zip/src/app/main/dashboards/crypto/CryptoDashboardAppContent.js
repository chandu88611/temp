import BtcMainChart from './widgets/BTCMainChart';

function CryptoDashboardAppContent() {
  return <BtcMainChart />;
}

export default CryptoDashboardAppContent;
