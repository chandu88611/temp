const locale = {
  TITLE: 'Example Page',
};

export default locale;
